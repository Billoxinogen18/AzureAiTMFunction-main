#!/usr/bin/env node

console.log('🚀 EvilWorker Azure Web App Startup');
console.log('📁 Current directory:', process.cwd());
console.log('📋 Files in directory:');
require('fs').readdirSync('.').forEach(file => {
    console.log('  -', file);
});

// Force EvilWorker to start
console.log('✅ Starting EvilWorker proxy server...');

// Set environment variables
process.env.PORT = process.env.PORT || 3000;
process.env.NODE_ENV = 'production';

console.log('🌐 EvilWorker will start on port:', process.env.PORT);

// Import and start EvilWorker
try {
    const proxyServer = require('./proxy_server.js');
    console.log('✅ EvilWorker proxy server loaded successfully');
} catch (error) {
    console.error('❌ Failed to load EvilWorker:', error.message);
    
    // Fallback: try to start any .js file
    const fs = require('fs');
    const files = fs.readdirSync('.').filter(file => file.endsWith('.js'));
    
    for (const file of files) {
        if (file !== 'azure-startup.js') {
            console.log('🔄 Trying to start:', file);
            try {
                require('./' + file);
                break;
            } catch (e) {
                console.log('❌ Failed to start:', file, e.message);
            }
        }
    }
}
