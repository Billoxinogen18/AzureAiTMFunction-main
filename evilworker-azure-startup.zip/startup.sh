#!/bin/bash

echo "🚀 EvilWorker Azure Web App Startup"
echo "📁 Current directory: $(pwd)"
echo "📋 Files in directory:"
ls -la

# Check if proxy_server.js exists
if [ -f "proxy_server.js" ]; then
    echo "✅ Found proxy_server.js, starting EvilWorker..."
    
    # Set environment variables
    export PORT=${PORT:-3000}
    export NODE_ENV=production
    
    echo "🌐 Starting EvilWorker on port $PORT"
    
    # Start EvilWorker proxy server
    exec node proxy_server.js
else
    echo "❌ proxy_server.js not found!"
    echo "📋 Available files:"
    ls -la
    
    # Fallback: try to start any .js file
    for file in *.js; do
        if [ -f "$file" ]; then
            echo "🔄 Trying to start: $file"
            exec node "$file"
            break
        fi
    done
    
    echo "❌ No JavaScript files found to start!"
    exit 1
fi
